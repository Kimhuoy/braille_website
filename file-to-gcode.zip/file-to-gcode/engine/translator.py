"""
Print text -> Braille lines: Khmer words (khmernltk), whole equations and abbreviations.

    text_to_braille("ទឹក H2O")                    Khmer Braille
    text_to_braille("Hello", "english")           English Braille (UEB uncontracted)
"""
import re

from khmernltk import word_tokenize

import english_braille
from KhmerToBrailleLogic import khmer_to_braille
from math_braille import ascii_to_cells, mark_formulas, math_to_braille, split_math_segments


class MathSegment(str):
    """An equation typed between ⟦ ⟧; translated by math_braille, not word by word."""


class Abbreviation(str):
    """Capitals with full stops (P.M.H.); word_tokenize would split it as 'P.', 'M.', 'H', '.'."""


ABBREVIATION_RE = re.compile(r"(?<![A-Za-z.])((?:[A-Z]\.){2,})")


def abbreviation_to_braille(abbr):
    """P.M.H. -> ,p4 ,m4 ,h4 : each letter with its full stop, then a space (Biology p.46)."""
    return ascii_to_cells(" ".join("," + letter.lower() + "4" for letter in abbr[::2]))


def tokenize_with_math(text, keep_newlines=True):
    """
    Split text into Khmer words (khmernltk), whole equations (⟦ ⟧) and
    abbreviations (P.M.H.). Equations stay in one piece so the math rules
    (fractions, scripts ...) can see the whole expression. Chemical formulas
    typed as plain text (H2O) are equations too, so 2 is a subscript (,h2,o).
    """
    tokens = []
    for is_math, chunk in split_math_segments(mark_formulas(text)):
        if is_math:
            tokens.append(MathSegment(chunk))
            continue
        # One line at a time. Padding the line break with spaces (" <NEWLINE> ")
        # used to end every Braille line with a blank cell and start the next with one.
        lines = chunk.split('\n') if keep_newlines else [chunk]
        for n, line in enumerate(lines):
            if n:
                tokens.append("<NEWLINE>")
            pieces = ABBREVIATION_RE.split(line)
            for k, piece in enumerate(pieces):
                if k % 2:
                    tokens.append(Abbreviation(piece))
                    continue
                body = piece.strip(' ')
                # keep the spaces next to an equation or abbreviation (word_tokenize drops edge spaces)
                if piece.startswith(' ') and tokens:
                    tokens.append(' ')
                if body:
                    tokens.extend(word_tokenize(body))
                    line_break_follows = k == len(pieces) - 1 and n < len(lines) - 1
                    if piece.endswith(' ') and not line_break_follows:
                        tokens.append(' ')
    return tokens


def format_khmer_and_braille_text(khmer_words, max_line_length=42, unmapped=None):
    formatted_lines = []
    current_braille_line = ""

    for word in khmer_words:

        # Explicit newline
        if word == "<NEWLINE>":
            if current_braille_line.strip():
                formatted_lines.append(current_braille_line)
                current_braille_line = ""
            # else: do NOTHING (no empty line)
            continue

        if isinstance(word, MathSegment):
            braille_word = math_to_braille(word, unmapped)
        elif isinstance(word, Abbreviation):
            braille_word = abbreviation_to_braille(word)
        else:
            braille_word = khmer_to_braille(word, unmapped)

        # A drawing or matrix (several Braille lines) starts on its own line so its columns line up
        if "\n" in braille_word:
            if current_braille_line.strip("⠀ "):
                formatted_lines.append(current_braille_line)
            formatted_lines.extend(braille_word.split("\n"))
            current_braille_line = ""
            continue

        # Oversized word protection
        if len(braille_word) > max_line_length:
            if current_braille_line.strip():
                formatted_lines.append(current_braille_line)
            formatted_lines.append(braille_word)
            current_braille_line = ""
            continue

        # Word-style wrapping
        if len(current_braille_line) + len(braille_word) > max_line_length:
            # The space at the break belongs to neither line (a blank cell would look like an indent)
            if current_braille_line.strip():
                formatted_lines.append(current_braille_line.rstrip("⠀ "))
            current_braille_line = braille_word.lstrip("⠀ ")
        else:
            current_braille_line += braille_word

    # Final flush
    if current_braille_line.strip():
        formatted_lines.append(current_braille_line)

    return formatted_lines


def wrap_braille_line(line, max_line_length=42):
    """Break a Braille line at blank cells so no line is longer than max_line_length."""
    lines, current = [], ""
    for word in re.split("(⠀)", line):
        if len(current) + len(word) > max_line_length and current.strip("⠀"):
            lines.append(current.rstrip("⠀"))
            current = word.lstrip("⠀")
        else:
            current += word
    lines.append(current)
    return "\n".join(lines)


def text_to_braille(text, braille_type="khmer", unmapped=None, keep_newlines=True, max_line_length=42):
    """
    Print text -> Braille: Khmer Braille, or English Braille (UEB uncontracted). Equations ⟦ ⟧ use the math rules.
    Lines are broken between words at max_line_length cells.
    """
    if braille_type != "english":
        tokens = tokenize_with_math(text, keep_newlines=keep_newlines)
        return "\n".join(format_khmer_and_braille_text(tokens, max_line_length=max_line_length, unmapped=unmapped))
    if not keep_newlines:
        text = text.replace("\n", " ")
    braille = "".join(math_to_braille(chunk, unmapped) if is_math else english_braille.to_braille(chunk, unmapped)
                      for is_math, chunk in split_math_segments(text))
    return "\n".join(wrap_braille_line(line, max_line_length) for line in braille.split("\n"))
