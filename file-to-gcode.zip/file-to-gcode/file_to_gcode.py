"""
Document -> Braille -> G-code for the embosser. One command:

    python file_to_gcode.py test.docx        -> test.gcode and test.braille.pdf, next to the document

test.gcode is for the embosser; test.braille.pdf shows the dots it will emboss.

Works with .docx, .doc (needs Microsoft Word on this computer), .txt and .pdf.

    python file_to_gcode.py a.docx b.pdf               several documents
    python file_to_gcode.py story.pdf -t english       English Braille instead of Khmer
    python file_to_gcode.py test.docx -o C:\\printer\\test.gcode


"""
import argparse
import contextlib
import io
import logging
import os
import re
import shutil
import sys
import tempfile

import fitz

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "engine"))

# The translators print debug output while loading and translating
with contextlib.redirect_stdout(io.StringIO()):
    import BrailleToGcodeV2 as gcode_writer  # noqa: E402
    import translator  # noqa: E402
    from FileFormat import UploadError, read_upload  # noqa: E402

BRAILLE_TYPES = ("khmer", "english")

# What the file reader's error codes mean (FileFormat.py)
ERRORS = {
    "unsupported": "not a .docx, .doc, .txt or .pdf file",
    "old_word": "old Word file (.doc): open it in Word and save it as .docx",
    "encoding": "the text file is not Unicode: save it as UTF-8 in Notepad",
    "unreadable": "the file is damaged or not really this type",
    "pdf_failed": "the PDF could not be read",
    "pdf_scanned": "scanned PDF, but Tesseract OCR with Khmer is not installed on this computer",
    "scan_too_long": "scanned PDF with more than 10 pages: split it, or use Word / .txt",
    "too_many_pages": "PDF with more than 200 pages: split it into parts",
    "too_long": "more than 300,000 characters (about 200 pages): split it into parts",
    "empty": "the file has no text",
    "braille_file": "this is already a Braille file",
    "duxbury": "Duxbury file (.dxb): this tool reads .txt, .docx and .pdf",
}


class ConversionError(Exception):
    """A file that could not be converted; the message says why, in plain words."""


def _long(path):
    """The path in Windows' long form (\\\\?\\C:\\...), so folders deeper than 260 characters work (OneDrive paths are long)."""
    path = os.path.abspath(path)
    if os.name == "nt" and not path.startswith("\\\\?\\"):
        return "\\\\?\\" + path
    return path


class _LocalFile:
    """A file on disk, in the shape read_upload expects (an uploaded file)."""

    def __init__(self, path):
        self.path = path
        self.filename = os.path.basename(path)

    def save(self, destination):
        shutil.copyfile(_long(self.path), destination)


def _doc_to_docx(doc_path, docx_path):
    """Old Word file -> .docx, with Microsoft Word (.doc is a closed format that only Word reads properly)."""
    try:
        import pythoncom
        import win32com.client
    except ImportError as error:
        raise ConversionError(ERRORS["old_word"]) from error
    pythoncom.CoInitialize()
    word = None
    try:
        # DispatchEx: its own Word, so a document the user has open stays open
        word = win32com.client.DispatchEx("Word.Application")
        word.Visible = False
        word.DisplayAlerts = 0
        document = word.Documents.Open(doc_path, ReadOnly=True, AddToRecentFiles=False, ConfirmConversions=False)
        document.SaveAs2(docx_path, FileFormat=16)      # 16 = .docx
        document.Close(False)
    except pythoncom.com_error as error:
        raise ConversionError(ERRORS["old_word"]) from error
    finally:
        if word is not None:
            word.Quit()
        pythoncom.CoUninitialize()


def cells_per_line(paper_width=gcode_writer.paperWidth_default):
    """Braille cells on one embossed line: the same sum as BrailleToGcodeV2 (5 mm margins, 6.5 mm per cell)."""
    margin_left = margin_right = 5.0
    cell_step = 6.5
    usable = paper_width - (margin_left + gcode_writer.machine_offset_left) - (margin_right + gcode_writer.machine_offset_right)
    return int(usable // cell_step)


def _is_braille(text):
    """True for a document that already holds Braille dots: it only needs embossing, not translating."""
    marks = [ch for ch in text if not ch.isspace()]
    return bool(marks) and sum("⠀" <= ch <= "⣿" for ch in marks) / len(marks) > 0.9


def translate_text(text, braille_type="khmer", paper_width=gcode_writer.paperWidth_default):
    """Print text -> (Braille lines as one string, characters that have no Braille code)."""
    if braille_type not in BRAILLE_TYPES:
        raise ConversionError(f"unknown Braille type '{braille_type}' (use khmer or english)")
    width = cells_per_line(paper_width)
    if _is_braille(text):
        braille = "\n".join(translator.wrap_braille_line(line, width) for line in text.split("\n"))
        return braille.rstrip("\n⠀ "), []
    unmapped = set()
    with contextlib.redirect_stdout(io.StringIO()):
        braille = translator.text_to_braille(text, braille_type, unmapped, keep_newlines=True, max_line_length=width)
    return braille.rstrip("\n⠀ "), sorted(unmapped)     # no blank lines fed at the end


def braille_to_gcode_file(braille, output_path, paper_width=gcode_writer.paperWidth_default,
                          paper_height=gcode_writer.paperHeight_default, feedrate=gcode_writer.feedRate_default):
    """
    Write the G-code for these Braille lines to output_path (replaced if it exists); returns the page count.
    Only machine commands go in the file: the comments BrailleToGcodeV2 writes are taken out.
    """
    lines = gcode_writer.clean_braille_text(braille)
    if not any("⠁" <= ch <= "⣿" for line in lines for ch in line):
        raise ConversionError("nothing to emboss: the translation has no Braille dots")
    os.makedirs(_long(os.path.dirname(os.path.abspath(output_path))), exist_ok=True)
    # BrailleToGcodeV2 adds (1), (2) ... to a name that exists, so write to a new
    # name in a short temporary folder and then copy it over the output file
    with tempfile.TemporaryDirectory() as tmp:
        tmp_path = os.path.join(tmp, "braille.gcode")
        with contextlib.redirect_stdout(io.StringIO()):
            gcode_writer.braille_to_gcode(lines, filename=tmp_path, Paper_width=paper_width,
                                          Paper_height=paper_height, feedrate=feedrate)
        with open(tmp_path, encoding="utf-8") as f:
            written = f.read().split("\n")
    pages = sum(1 for line in written if line.startswith("; Start Page"))
    commands = [line.split(";")[0].strip() for line in written]
    with open(_long(output_path), "w", encoding="utf-8") as f:
        f.write("\n".join(re.sub(" +", " ", code) for code in commands if code) + "\n")
    return pages


def gcode_to_pdf(gcode_path, pdf_path, paper_width=gcode_writer.paperWidth_default,
                 paper_height=gcode_writer.paperHeight_default):
    """
    Draw what the embosser will do: follow the G-code's moves and draw a dot wherever
    it embosses one, at its real position and size, one PDF page per sheet of paper.
    Returns the number of dots drawn.
    """
    mm = 72 / 25.4
    dot_radius = 0.75 * mm                  # base of a dot: 1.5 mm (Technical Document B1)
    x = y = 0.0
    sheets = [[]]
    with open(_long(gcode_path), encoding="utf-8") as f:
        for raw in f:
            code = raw.split(";")[0].strip()
            if code.startswith("G1"):
                move_x, move_y = re.search(r"X(-?[\d.]+)", code), re.search(r"Y(-?[\d.]+)", code)
                x = float(move_x.group(1)) if move_x else x
                y = float(move_y.group(1)) if move_y else y
            elif code.startswith("M0"):     # the machine pauses for the next sheet
                sheets.append([])
            elif code.startswith("M3 S255"):
                sheets[-1].append((x + gcode_writer.machine_offset_left, y))

    pdf = fitz.open()
    for dots in sheets:
        page = pdf.new_page(width=paper_width * mm, height=paper_height * mm)
        shape = page.new_shape()
        for dot_x, dot_y in dots:
            shape.draw_circle(fitz.Point(dot_x * mm, dot_y * mm), dot_radius)
        shape.finish(color=None, fill=(0, 0, 0))
        shape.commit()
    with open(_long(pdf_path), "wb") as f:
        f.write(pdf.tobytes())
    return sum(len(dots) for dots in sheets)


def convert_file(input_path, output_path=None, braille_type="khmer", save_braille=False,
                 paper_width=gcode_writer.paperWidth_default, paper_height=gcode_writer.paperHeight_default,
                 feedrate=gcode_writer.feedRate_default):
    """
    The whole process for one document: read it -> translate to Braille -> write
    the G-code and <name>.braille.pdf (the dots the G-code embosses).
    output_path defaults to <name>.gcode next to the document; the PDF goes next to
    the G-code. save_braille also writes <name>.braille.txt (the Braille as text).
    Returns a summary dict.
    """
    if not os.path.isfile(_long(input_path)):
        raise ConversionError("file not found")
    if output_path is None:
        output_path = os.path.splitext(input_path)[0] + ".gcode"
    try:
        with contextlib.redirect_stdout(io.StringIO()), tempfile.TemporaryDirectory() as tmp:
            source = input_path
            if input_path.lower().endswith(".doc"):
                # Word works in a short temporary folder: it refuses very long paths
                short_doc, source = os.path.join(tmp, "in.doc"), os.path.join(tmp, "in.docx")
                shutil.copyfile(_long(input_path), short_doc)
                _doc_to_docx(short_doc, source)
            text = read_upload(_LocalFile(source))
    except UploadError as error:
        raise ConversionError(ERRORS.get(str(error), str(error))) from error

    braille, unmapped = translate_text(text, braille_type, paper_width)
    pages = braille_to_gcode_file(braille, output_path, paper_width, paper_height, feedrate)
    if save_braille:
        with open(_long(os.path.splitext(output_path)[0] + ".braille.txt"), "w", encoding="utf-8") as f:
            f.write(braille)
    # .braille.pdf, not .pdf: story.pdf must not be replaced by its own Braille
    pdf_path = os.path.splitext(output_path)[0] + ".braille.pdf"
    gcode_to_pdf(output_path, pdf_path, paper_width, paper_height)
    return {"input": input_path, "output": output_path, "pdf": pdf_path, "braille": braille,
            "lines": braille.count("\n") + 1, "pages": pages, "unmapped": unmapped}


def _short(path):
    """The path from where you are, when that is shorter to read."""
    try:
        return os.path.relpath(path)
    except ValueError:      # another drive
        return path


def main(argv=None):
    parser = argparse.ArgumentParser(
        description="Translate .docx, .doc, .txt and .pdf files to Braille: writes embosser G-code and a Braille PDF.")
    parser.add_argument("files", nargs="+", help="the documents to convert")
    parser.add_argument("-o", "--output",
                        help="output .gcode file (one document) or folder (default: next to each document); the PDF goes with it")
    parser.add_argument("-t", "--braille-type", choices=BRAILLE_TYPES, default="khmer",
                        help="khmer (default) or english (UEB grade 1)")
    parser.add_argument("--braille-txt", action="store_true",
                        help="also save the Braille as <name>.braille.txt, to check it before embossing")
    parser.add_argument("--paper-width", type=float, default=gcode_writer.paperWidth_default, help="mm (default A4: 210)")
    parser.add_argument("--paper-height", type=float, default=gcode_writer.paperHeight_default, help="mm (default A4: 297)")
    parser.add_argument("--feedrate", type=int, default=gcode_writer.feedRate_default, help="mm/min (default 6000)")
    args = parser.parse_args(argv)
    logging.disable(logging.INFO)       # only the result: the word-splitting model logs a line when it loads

    files = args.files
    one_file_output = args.output if args.output and args.output.lower().endswith(".gcode") else None
    if one_file_output and len(files) > 1:
        parser.error("-o NAME.gcode is for one file; give a folder for several files")
    out_dir = args.output if args.output and not one_file_output else None

    failed = 0
    for path in files:
        name = os.path.splitext(os.path.basename(path))[0]
        target = one_file_output or (os.path.join(out_dir, name + ".gcode") if out_dir else None)
        try:
            result = convert_file(path, target, args.braille_type, args.braille_txt,
                                  args.paper_width, args.paper_height, args.feedrate)
        except ConversionError as error:
            failed += 1
            print(f"FAILED  {os.path.basename(path)}: {error}")
            continue
        print(f"OK      {os.path.basename(path)} -> {_short(result['output'])}  "
              f"({result['lines']} Braille lines, {result['pages']} page(s))")
        print(f"        {' ' * len(os.path.basename(path))}-> {_short(result['pdf'])}")
        if result["unmapped"]:
            print(f"        no Braille code for: {' '.join(result['unmapped'])} (left out)")
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main())
