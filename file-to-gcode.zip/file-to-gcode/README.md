# File to G-code

One command turns a document into G-code for the Braille embosser and a PDF of
the Braille:

```
python file_to_gcode.py test.docx
```

```
OK      test.docx -> test.gcode  (33 Braille lines, 2 page(s))
                  -> test.braille.pdf
```

It reads the file, translates it to Braille and writes both files. There is no
website or interface.

* **Input:** `.docx`, `.doc`, `.txt` or `.pdf`. A `.doc` needs Microsoft Word on
  the computer. A PDF made from Word is read from its own text; a scanned PDF is
  read with OCR, which needs Tesseract with Khmer installed and works for 10
  pages at most. A file that already holds Braille dots skips translation.
* **Output,** next to the document:
  * `<name>.gcode`, ready for the embosser. It uses A4 paper with up to 26 cells
    per line and 23 lines per page, and pauses (`M0`) before each new sheet.
  * `<name>.braille.pdf`, to see the Braille: the dots the G-code will emboss, at
    their real size and position, one PDF page per sheet. It is only a picture;
    printing it gives flat ink dots, not raised Braille.

This is a project of its own: everything it needs is in this folder, so the
folder can be moved to another location. Keep the folder's full path under 200
characters: Python on Windows cannot load the code from deeper paths.

`file_to_gcode.py` is the command you run. The code behind it is in `engine/`:

* `FileFormat.py` reads the file.
* `translator.py` translates it to Khmer or English Braille, including math,
  chemistry, and formulas such as H2O. It uses `KhmerToBrailleLogic.py`,
  `gcc_segmentation.py`, `math_braille.py`, `english_braille.py` and the three
  `.json` dictionaries.
* `BrailleToGcodeV2.py` writes the G-code.

This code started as a copy of the Braille website's backend (2 November 2026)
without the web server parts. The two are now separate: a fix made in one has to
be made in the other by hand.

## Setup

```
pip install -r requirements.txt
```

## Other ways to run it

| Command | What it does |
|---|---|
| `python file_to_gcode.py C:\docs\lesson.pdf` | Saves `C:\docs\lesson.gcode` and `C:\docs\lesson.braille.pdf` |
| `python file_to_gcode.py a.docx b.txt` | Several documents |
| `python file_to_gcode.py lesson.docx -o C:\printer\lesson.gcode` | Choose the output file |
| `python file_to_gcode.py a.docx b.txt -o C:\printer` | Several documents into one folder |
| `python file_to_gcode.py story.txt -t english` | English Braille (UEB grade 1) instead of Khmer |
| `python file_to_gcode.py test.docx --braille-txt` | Also save `test.braille.txt`, to check the Braille before embossing |
| `python file_to_gcode.py test.docx --paper-width 200 --paper-height 280` | Another paper size (mm); the line length follows |
| `python file_to_gcode.py test.docx --feedrate 4000` | Slower moves (mm/min, default 6000) |

If a G-code or Braille PDF with that name exists, it is replaced. A document that cannot
be converted gives the reason:

```
FAILED  photo.png: not a .docx, .doc, .txt or .pdf file
```

The exit code is 0 when every file was converted and 1 when one failed, so
the tool can be run from a script or a scheduled task.

## From Python

```python
from file_to_gcode import convert_file

result = convert_file("lesson.docx", braille_type="khmer")
result["pages"], result["unmapped"]      # 2, []  (unmapped = characters with no Braille code)
```

`translate_text(text)` and `braille_to_gcode_file(braille, path)` can also be
used on their own.

## Limits

* 300,000 characters per file (about 200 pages)
* 200 PDF pages
* 10 scanned pages

Split bigger documents into parts. Characters that have no Braille code are
listed after the file name, and left out of the G-code.

## Test

From this folder:

```
python -I -X utf8 tests/test_file_to_gcode.py
python -I -X utf8 tests/test_gcode_end_to_end.py
```

`test_gcode_end_to_end.py` runs the whole process. It reads the G-code back the
way the embosser follows it and checks that the dots spell the translation line
by line, with no blank line and no blank sheet.
